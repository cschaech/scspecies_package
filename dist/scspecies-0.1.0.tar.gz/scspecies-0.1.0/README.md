# scSpecies

A toolkit for (brief one-line description).

## Installation

```bash
pip install scspecies
